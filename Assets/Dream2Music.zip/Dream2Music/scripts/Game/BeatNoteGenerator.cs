﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeatNoteGenerator : MonoBehaviour{//Singleton<BeatNoteGenerator> {

	[SerializeField]
	BeatNoteRenderer noteRendererTemplate;
	[SerializeField]
	Transform[] padTransforms;

	public AudioTrack bindTrack;

	//generate before the hitting timing
	public static float beatNoteMoveTimeLength = 1;
	//public static float beatNoteMoveDistance;
	//get from other thing
	float looplength;
	//SortedList<float,NoteEvent> predictedNoteEvents;
	SortedList<float,BeatNoteRenderer> noteRenderers;
	
	public void generatePreditedNotes(SortedList<float,NoteEvent> noteEvents){
		//predictedNoteEvents = new SortedList<float,NoteEvent>();
		noteRenderers = new SortedList<float,BeatNoteRenderer>();
		foreach(var note in noteEvents)
		{
			var stamp = predictNoteBeatStamp(note.Key);
		//	predictedNoteEvents.Add(stamp,note.Value);
			var noteRenderer = Instantiate(noteRendererTemplate);
			noteRenderers.Add(stamp,noteRenderer);
			noteRenderer.hitPostition = padTransforms[note.Value.message.pitch].position;
		}
	}
	float predictNoteBeatStamp(float stampOri)
	{
		float startStamp = stampOri - beatNoteMoveTimeLength;
		if(startStamp<0)
		{
			startStamp += looplength;
		}
		return startStamp;
	}

	BeatNoteRenderer currentNote{
		get{
			if(noteRenderers.Count>currentNoteIndex)
				return noteRenderers[currentNoteIndex];
			else
				return null;
		}
	}
	int currentNoteIndex = 0;
	public void backToHead()
	{
		currentNoteIndex = 0;
	}
	public void loopUpdate(float beatStamp)
	{
		if(!currentNote)
		{
			return;
		}
		while(AudioLooper.playNoteTimingTest(currentNote.bindEvent.beatStamp,beatStamp))
		{
			currentNote.gameObject.SetActive(true);
			currentNote.Go();
			currentNoteIndex++;
		}
		//maybe not nessersory
		/*
		foreach(var note in noteRenderers.Values)
		{
			if(note.isActive)
			{
				note.moveUpdate();
			}
		}*/
	}
	


}
