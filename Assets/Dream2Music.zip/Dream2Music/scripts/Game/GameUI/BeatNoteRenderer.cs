﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class BeatNoteRenderer : MonoBehaviour {
	public int pitch{
		get{
			return bindEvent.message.pitch;
		}
	}
	public NoteEvent bindEvent;
	public int targetStamp;
	SpriteRenderer spr;
	[HideInInspector]
	public Vector3 hitPostition;

	void Awake()
	{
		spr = GetComponent<SpriteRenderer>();
	}
	public bool isActive
	{
		get{
			return gameObject.activeSelf;
		}
	}
	
	public void Go(){
		transform.DOMove(hitPostition,BeatNoteGenerator.beatNoteMoveTimeLength);
		transform.position = hitPostition-Vector3.zero;
	}
	
	public void hitAnimation()
	{
		transform.DOScale(5,0.5f);
		spr.DOColor(Color.clear,0.5f).OnComplete(()=>{
			Done();
		});
	}
	public void missAnimation()
	{
		spr.color = Color.black;
		spr.DOColor(Color.clear,0.5f).OnComplete(()=>{
			Done();
		});
	}
	public void Done()
	{
		gameObject.SetActive(false);
	}
}