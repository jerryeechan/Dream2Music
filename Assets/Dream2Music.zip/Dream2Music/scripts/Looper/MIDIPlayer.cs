﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MidiJack;
public class MIDIPlayer : Singleton<MIDIPlayer> {

	[SerializeField]
	public AudioChannel[] channels;

	List<AudioTrack> tracks;
	
	AudioTrack playingTrack;
	AudioTrack metronomeTrack;
	bool isRecording = true;
	
	public void playTrack(int index)
	{
		if(index==0)
		{
			Debug.LogError("Don't play metronomeTrack");
			return;
		}
		playingTrack = tracks[index];
	}
	// Use this for initialization
	void Awake () {
		MidiDriver.Instance.noteOnDelegate += NoteOn;
		MidiDriver.Instance.noteOffDelegate += NoteOff;
		playingTrack = new AudioTrack(new TrackData(0));
		tracks = new List<AudioTrack>();
		prepareMetronomeTrack();
		tracks.Add(playingTrack);
	}
	void prepareMetronomeTrack()
	{
		metronomeTrack = new AudioTrack(new TrackData(0));
		
		for(int i=0;i<AudioLooper.instance.loopLength;i++)
		{
			metronomeTrack.addEvent(new NoteEvent(i,NoteEventType.NoteOn,new NoteMessage(7)));
			metronomeTrack.addEvent(new NoteEvent(i+0.1f,NoteEventType.NoteOff,new NoteMessage(7)));
		}
		tracks.Add(metronomeTrack);
	}
	public void addTrack(AudioTrack track)
	{
		tracks.Add(track);
	}
	[SerializeField]
	BeatNoteGenerator gameNoteGenerator;
	void NoteOn(MidiChannel channel, int note, float velocity){
		if(note==63)
		{
			playingTrack.Clear();
			gameNoteGenerator.generatePreditedNotes(playingTrack.sortedEvents);
		}
		else
		{
			if(isRecording)
			{
				print("record on");
				playingTrack.addEvent(new NoteEvent(AudioLooper.instance.beatStamp,NoteEventType.NoteOn,new NoteMessage(note,velocity)));
			}
		}
	}
	void NoteOff(MidiChannel channel, int note){
		if(note==63)
		{
			return;
		}
		//playingTrack.NoteOn(new NoteMessage(note));
		if(isRecording)
		{
			print("record off");
			playingTrack.addEvent(new NoteEvent(AudioLooper.instance.beatStamp,NoteEventType.NoteOff,new NoteMessage(note)));
		}
		//channels[(int)channel].NoteOff(new NoteMessage(note));
	}
	// Update is called once per frame
	public void loopUpdate(float beatStamp) {
		//metronomeTrack.looperUpdate(beatStamp);
		foreach(var track in tracks)
		{
			if(beatStamp==0)
				track.backToHead();
			track.looperUpdate(beatStamp);
		}
	}
}
