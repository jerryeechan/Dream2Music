﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class AudioTrack{
    public string name;
    public bool mute=false;
    public AudioTrack(TrackData data)
    {
        loadFromData(data);
    }
    void loadFromData(TrackData data)
    {
        Debug.Log("track loaded");
        trackData = data;
        bindChannel = MIDIPlayer.instance.channels[trackData.channel];
        sortedEvents = new SortedList<float,NoteEvent>(new DuplicateKeyComparer<float>());
        if(trackData.noteEvents!=null)
        {
            foreach(var eve in trackData.noteEvents)
            {
                sortedEvents.Add(eve.beatStamp,eve);
            }
        }
        
    }
    public AudioChannel bindChannel;
    TrackData trackData;

    //temp events;
    //List<NoteEvent> noteEvents;
    
    public SortedList<float,NoteEvent> sortedEvents;
    
    public void saveToData()
    {
        trackData.noteEvents = new NoteEvent[sortedEvents.Count];
        trackData.channel = bindChannel.channelNum;
        sortedEvents.Values.CopyTo(trackData.noteEvents,0);
    }
    int currentEventIndex = 0;
    public void backToHead()
    {
        currentEventIndex = 0;
    }
    public void looperUpdate(float beatstamp)
    {
        while(testEvent(beatstamp)){}
    }
    public bool testEvent(float beatstamp)
    {   
        
        
        if(sortedEvents.Count<=currentEventIndex)
        {
            return false;
        }
        else{
            var currentEvent = sortedEvents.Values[currentEventIndex];
            
            if(AudioLooper.playNoteTimingTest(currentEvent.beatStamp,beatstamp))
            {
                Debug.Log(""+beatstamp+" "+currentEvent.beatStamp);
                triggerEvent(currentEvent);
                currentEventIndex++;
                return true;
            }
            return false;
        }
    }
    //Note[] notes;
    public void triggerEvent(NoteEvent ne)
    {
        switch(ne.eventType)
        {
            case NoteEventType.NoteOn:
                NoteOn(ne.message);
            break;
            case NoteEventType.NoteOff:
                NoteOff(ne.message);
                //notes[ne.message.pitch].Stop();
            break;
        }
    }
    public void addEvent(NoteEvent ne)
    {
        //noteEvents.Add(ne);
        sortedEvents.Add(ne.beatStamp,ne);
    }
    public void NoteOn(NoteMessage message)
    {
        if(mute==false)
            bindChannel.NoteOn(message);
    }
    public void NoteOff(NoteMessage message)
    {
        bindChannel.NoteOff(message);
    }
    public void Clear()
    {
        sortedEvents.Clear();
    }
}
public class DuplicateKeyComparer<TKey>:IComparer<TKey> where TKey : IComparable
{
    #region IComparer<TKey> Members

    public int Compare(TKey x, TKey y)
    {
        int result = x.CompareTo(y);

        if (result == 0)
            return 1;   // Handle equality as beeing greater
        else
            return result;
    }

    #endregion
}